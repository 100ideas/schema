---
title: BlockContent
authors: []
---

Union type for valid block content.

## Properties

|  |
