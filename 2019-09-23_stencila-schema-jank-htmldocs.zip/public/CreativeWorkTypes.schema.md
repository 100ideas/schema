---
title: CreativeWorkTypes
authors: []
---

Union type for call CreativeWork types.

## Properties

|  |
