---
title: InlineContent
authors: []
---

Union type for valid inline content.

## Properties

|  |
