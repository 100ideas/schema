---
title: Node
authors: []
---

Union type for all valid nodes.

## Properties

|  |
