---
title: SchemaTypes
authors: []
---

Union type for all data schemas.

## Properties

|  |
